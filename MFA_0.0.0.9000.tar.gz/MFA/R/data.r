#' A dataset containing Wine score of 12 wines from 10 wine accessors.
#'

"wine"